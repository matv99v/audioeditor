export function pressPlay() {
    return {
        type: 'PRESS_PLAY'
    };
}

export function pressStop() {
    return {
        type: 'PRESS_STOP'
    };
}
