export const PATH_TO_VIDEO = './media/snowboard.mp4';
// export const PATH_TO_VIDEO = '../media/heels-replace2.mp4';
export const BAR_WIDTH     = 4;
export const MARKER_WIDTH  = 4;
export const TRACK_HEIGHT  = 82;
export const TRACK_HEAD    = 20;
